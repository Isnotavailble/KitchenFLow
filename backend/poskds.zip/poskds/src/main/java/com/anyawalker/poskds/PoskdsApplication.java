package com.anyawalker.poskds;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PoskdsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PoskdsApplication.class, args);
	}

}
